Aye Welcome!!!!!

This is my choose your own adventure game that is incomplete so yeah justtype make and everything is compiled for you isnt that nice! Have fun andenjoy if you have any questions kust let me know!

Have fun!!!,
Zach
